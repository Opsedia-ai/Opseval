# SPDX-License-Identifier: Apache-2.0
"""Opseval: name reservation. The first functional release will be 0.1.0."""

__version__ = "0.0.1"
