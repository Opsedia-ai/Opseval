# opseval

**Opseval** is an open-source, black-box evaluation framework for conversational AI agents, built by Opsedia.

This `0.0.1` release only reserves the package name. It contains no functionality yet. The first usable release will be `0.1.0`.
